from pprint import pformat
from conllu import parse 
import requests

INPUT_FILE = "file_name.txt" # the name of the file for segmentation (or the path to this file); use only the txt files and UTF-8 coding
OUTPUT_FILE = "segmented_text_file_name.txt" # name of the file for saving the results of segmentation


def bez_interpunkce(veta):
    """vyhodí z věty interpunkční znaménka bo v UD tvoří samostatné tokeny"""

    return veta.filter(xpos=lambda x: x != "Z:-------------") 


def hledani_predikatu(poradi_vety):
    """najde predikáty v dané větě a uloží jejich id a form"""

    predikaty_id = []
    predikaty_form = []
    morfo_kategorie_predikatu = ("VB", "Vp", "Vi", "Vs")
    aktualni_veta = parsovani[poradi_vety]
    aktualni_veta = bez_interpunkce(aktualni_veta)
    for token in aktualni_veta:

        if token["upos"] == "VERB" and token["xpos"][0:2] in morfo_kategorie_predikatu:
            if token["id"] not in predikaty_id:
                predikaty_id.append(token["id"])
                predikaty_form.append(token["form"])

        if token["upos"] == "AUX" and token["xpos"][0:2] in morfo_kategorie_predikatu:
            nominalni_cast_id = int(token["head"])
            for token_pomocny in aktualni_veta:
                if token_pomocny["id"] == nominalni_cast_id:
                    if token_pomocny["id"] not in predikaty_id:
                        predikaty_id.append(token_pomocny["id"])
                        predikaty_form.append(token_pomocny["form"])
        
            if nominalni_cast_id == 0:   
                predikaty_id.append(token["id"])
                predikaty_form.append(token["form"])

    return predikaty_id, predikaty_form

def hledani_frazi(poradi_vety, hlava, predikaty_vety):
    """najde fráze (=přímé uzly) jednotlivých klauzí; uloží, aby zachováno info o struktuře věta-klauze-fráze"""

    hlavy_frazi_klauze_id = []
    hlavy_frazi_klauze_form = []

    aktualni_veta = parsovani[poradi_vety]
    aktualni_veta = bez_interpunkce(aktualni_veta)

    for token in aktualni_veta:
        if token["id"] != hlava and token["id"] not in predikaty_vety and token["head"] == hlava:
            hlavy_frazi_klauze_id.append(token["id"])
            hlavy_frazi_klauze_form.append(token["form"])

    return hlavy_frazi_klauze_id, hlavy_frazi_klauze_form


### here the fun begins

text = INPUT_FILE
soubor = open(text, encoding="UTF-8")

# UDPipe parsing
data_z_webu = requests.post('http://lindat.mff.cuni.cz/services/udpipe/api/process', data={'tokenizer': "", 'tagger': "", 'parser': ""}, files={"data": soubor})
soubor.close()
data = data_z_webu.json()['result'] 

# python lib conllu processing
parsovani = parse(data)

# solving of problematic places (UD processing of conditional)
for veta in parsovani:
    for token_pomocny in veta: 
        if type(token_pomocny["id"]) is not int: 
            id_pomocne = token_pomocny["id"][0] 
            form_pomocne = token_pomocny["form"] 
            for token_pomocny_dva in veta:
                if token_pomocny_dva["id"] == id_pomocne:
                    token_pomocny_dva["head"] = None 


# saving information about sentences
vety_infa = []
for poradi_vety, veta in enumerate(parsovani):

    veta_info = {}
    veta_info["id věty"] = int(veta.metadata["sent_id"])
    veta_info["text"] = veta.metadata["text"] # saving the text of the sentence
    veta_info["predikáty id"], veta_info["predikáty form"] = hledani_predikatu(poradi_vety)
    veta_info["délka v počtu klauzí"] = len(veta_info["predikáty id"])
    vety_infa.append(veta_info)

for poradi_vety, veta_info in enumerate(vety_infa):
    hlavy_frazi_veta_id = []
    hlavy_frazi_veta_form = []
    delky_klauzi = []

    for hlava_klauze in veta_info["predikáty id"]:
        fraze_klauze_id, fraze_klauze_form  = hledani_frazi(poradi_vety, hlava_klauze, veta_info["predikáty id"])
        hlavy_frazi_veta_id.append(fraze_klauze_id)
        hlavy_frazi_veta_form.append(fraze_klauze_form)

    veta_info["hlavy frází form"] = hlavy_frazi_veta_form
    veta_info["hlavy frází id"] = hlavy_frazi_veta_id
    
    for klauze in veta_info["hlavy frází id"]:
        delka_klauze = len(klauze)
        delky_klauzi.append(delka_klauze)
    veta_info["délky klauzí"] = delky_klauzi


# all sentence information
vety_infa_text = ""
for polozka in vety_infa:
    vety_infa_text = vety_infa_text + pformat(polozka) + "\n\n"

# saving the text of each sentence as segmented by UDPipe
vety_na_radku = []
for polozka in vety_infa:
    vety_na_radku.append(polozka["text"])

with open(OUTPUT_FILE, "w", encoding="UTF-8") as file: 
    for veta in vety_na_radku:
        file.write(veta + "\n\n")
